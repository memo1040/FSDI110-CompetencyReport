const CouponForm = () => {
  const handleSave = () => {
    console.log("Saving discount");
  };

  return (
    <div className="coupon-form">
      <h3>Manage your Coupons</h3>
      <div className="my-control">
        <label>Code</label>
        <input name="code" type="text" />
      </div>
      <div className="my-control">
        <label>Discount</label>
        <input name="discount" type="number" />
      </div>
      <div className="my-control">
        <button onClick={handleSave} className="btn btn-dark">
          Register Coupon
        </button>
      </div>
    </div>
  );
};

export default CouponForm;
