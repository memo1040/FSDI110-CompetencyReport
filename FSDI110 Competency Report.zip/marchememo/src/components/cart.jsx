import { useContext } from "react";
import "./cart.css";
import StoreContext from "../context/storeContext";
import ItemInCart from "./itemInCart";
import DataService from "../services/dataService";

const Cart = () => {
  const prodsInCart = useContext(StoreContext).cart;

  const saveTheOrder = () => {
    //create the object
    let ord = {
      products: Cart,
      userId: 2139,
      coupon: "",
    };

    let service = new DataService();
    service.submitOrder(ord);
  };

  return (
    <div className="cart-page">
      <div className="header">
        <h3>All set?</h3>
      </div>

      <div className="row">
        <div className="col-9">
          <h4>Items in cart:</h4>

          {prodsInCart.map((p) => (
            <ItemInCart data={p}></ItemInCart>
          ))}
        </div>

        <div className="col-3 col-total">
          <h4>Total:</h4>
          <h3>$9,000.00</h3>

          <hr />

          <div className="coupon-form">
            <input type="text" placeholder="enter coupon code" />
            <button className="btn btn-sm btn-dark">Apply</button>
          </div>

          <hr />

          <button className="btn btn0-section btn-primary">Checkout</button>
        </div>
      </div>
    </div>
  );
};

export default Cart;
