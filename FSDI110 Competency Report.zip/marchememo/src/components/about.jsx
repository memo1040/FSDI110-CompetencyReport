import "./about.css";

const About = () => {
  return (
    <div className="about-page">
      <h1>About me: </h1>
      <h5>Guillermo Monge</h5>
      <hr />
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic et
        voluptates obcaecati saepe neque officiis repudiandae ad, architecto
        reprehenderit. Doloremque maiores omnis blanditiis nesciunt eveniet
        tenetur vero at reprehenderit corporis.
      </p>
    </div>
  );
};

export default About;
