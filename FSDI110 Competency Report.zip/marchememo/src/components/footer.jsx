import "./footer.css";

function Footer() {
  return (
    <div className="footer">
      <h5>Marché Memo. All Rights Reserved &copy; 2021</h5>
      <h6>Guillermo Monge</h6>
    </div>
  );
}

export default Footer;
