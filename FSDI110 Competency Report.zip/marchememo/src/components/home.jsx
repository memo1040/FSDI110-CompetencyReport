import "./home.css";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="home-page">
      <div className="top-banner">
        <div className="top-banner-text">
          <h1>Marché Memo</h1>
          <h2>Everything Organic</h2>
        </div>
        <img src="/images/organic.jpeg" alt="organic food"></img>
      </div>

      <div className="jumbotron mb-0">
        <div className="jumbo-message pr-5 pt-5">
          <h3 className="display-4">From the field to your table</h3>
          <p className="lead">Only the freshest products</p>
          <hr className="my-4" />
          <Link className="btn btn-info btn-lg" to="/catalog">
            Check our offerings{" "}
            <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
