import axios from "axios";

var catalog = [
  {
    _id: "45678909876545678",
    price: 2.0,
    stock: 10,
    title: "Apple",
    image: "apple.jpeg",
    discount: 1,
    category: "Fruit",
  },
  {
    _id: "2345678987654345678",
    price: 1.5,
    stock: 18,
    title: "Banana",
    image: "banana.jpeg",
    discount: 0,
    category: "Fruit",
  },
  {
    _id: "3456789876543456789",
    price: 5.0,
    stock: 6,
    title: "Bread",
    image: "bread.jpeg",
    discount: 2,
    category: "Bread & Cereals",
  },
  {
    _id: "345678909876543456789",
    price: 4.0,
    stock: 23,
    title: "Corn Flakes",
    image: "cornflakes.jpeg",
    discount: 1,
    category: "Bread & Cereals",
  },
  {
    _id: "098765432345678987654",
    price: 3.5,
    stock: 8,
    title: "Milk",
    image: "milk.jpeg",
    discount: 0,
    category: "Dairy & Eggs",
  },
  {
    _id: "345678909876543456789",
    price: 5.0,
    stock: 15,
    title: "Eggs",
    image: "eggs.jpeg",
    discount: 2,
    category: "Dairy & Eggs",
  },
];

class DataService {
  async getCatalog() {
    //call the server to get catalog
    let res = await axios.get("http://127.0.0.1:5000/api/catalog");
    return res.data; // = an array of objects

    //return mock data (temporal)
    //return catalog;
  }

  // get categories
  // http://127.0.0.1:5000/api/categories
  async getCategories() {
    let res = await axios.get("http://127.0.0.1:5000/api/categories");
    return res.data;
  }

  async saveProduct(prod) {
    let res = await axios.post("http://127.0.0.1:5000/api/catalog", prod);
    console.log("saving result", res.data);
    return res.data;
  }

  saveItem() {}

  saveOrder() {}

  serverURL = "http://127.0.0.1:5000";

  async submitOrder(order) {
    let res = await axios.post(this.serverURL + "/api/order", order);
    console.log("Saving your order", res.data);
  }
}

export default DataService;
